﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1: Form
    {
        void calcular()
        {
            double altura;
            double peso;
            if (double.TryParse(mskbxAltura.Text, out altura) && altura > 0.0)
            {
                if (double.TryParse(mskbxPeso.Text, out peso) && peso > 0.0)
                {
                    double imc = peso / Math.Pow(altura, 2);
                    imc = Math.Round(imc, 1);
                    tbxImc.Text = imc.ToString();
                    if (imc <= 18.5) { MessageBox.Show("Magreza"); }
                    else
                    if (imc <= 24.9) { MessageBox.Show("Normal"); }
                    else
                    if (imc <= 29.9) { MessageBox.Show("Sobrepeso"); }
                    else
                    if (imc <= 39.9) { MessageBox.Show("Obesidade"); }
                    else { MessageBox.Show("Obesidade Grave");}
                }
                else
                {
                    MessageBox.Show("Peso invalido: " + mskbxPeso.Text + ".");
                    mskbxPeso.Focus();
                }
            }
            else
            {
                MessageBox.Show("Altura invalida: " + mskbxAltura.Text + ".");
                mskbxAltura.Focus();
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
            calcular();
        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            tbxImc.Clear();
            mskbxPeso.Focus();
        }

        private void btSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mskbxPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            int key = e.KeyChar;
            if(13 == key)
            {
                mskbxAltura.Focus();
            }
        }

        private void mskbxAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            int key = e.KeyChar;
            if (13 == key)
            {
                calcular();
                mskbxPeso.Focus();
            }
        }
    }
}
