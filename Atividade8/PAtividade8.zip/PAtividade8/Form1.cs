﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] numberList = new int[20];
            bool sair = false;
            for(int i = 0; i < numberList.Length && !sair; i++)
            {
                while(true)
                {
                    string aux = Interaction.InputBox("Digite o numero", "Entrada de dados");
                    if(int.TryParse(aux, out int n))
                    {
                        numberList[i] = n;
                        break;
                    }
                    MessageBox.Show("Não é numero");
                }
            }

            Array.Reverse(numberList);

            {
                string a = "";
                foreach (var number in numberList)
                {
                    a += number + "\n";
                }
                MessageBox.Show(a);
            }
            {
                string b;
                b = string.Join("\n", numberList);
                MessageBox.Show(b);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string saida = "";
            for(int aluno = 0; aluno < 20; aluno++)
            {
                double soma = 0;
                for(int nota = 0; nota < 3; nota++)
                {
                    string aux = Interaction.InputBox($"Digita a nota {nota + 1} do aluno {aluno + 1}", "Entrada de Notas");
                    if(!double.TryParse(aux, out notas[aluno, nota]) || 
                        notas[aluno, nota] < 0 || 
                        notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("Nota invalida");
                        nota--;
                    }
                    else
                    {
                        soma += notas[aluno, nota];
                    }
                }
                saida += $"Aluno {aluno + 1}: média: {(soma / 3).ToString("N2")} \n";
            }
            MessageBox.Show(saida);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmExercicio4 form4 = new FrmExercicio4();
            form4.Show();
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Beatriz");
            alunos.Add("Camila");
            alunos.Add("João");
            alunos.Add("Joana");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.RemoveAt(6);

            string msg = "";

            foreach (var aluno in alunos)
            {
                msg += aluno + "\n";
            }
            MessageBox.Show(msg);
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            formExercicio5 form5 = new formExercicio5();
            form5.Show();
        }
    }
}
