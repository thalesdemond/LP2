﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class FrmExercicio4: Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nameList = new string[10];
            int[] nameSizeList = new int[10];

            for(int i = 0; i < nameList.Length; i++)
            {
                nameList[i] = Interaction.InputBox($"Digite o nome {i}", "");
                nameSizeList[i] = nameList[i].Replace(" ", "").Length;
                if (nameSizeList[i] == 0)
                {
                    MessageBox.Show("Valor invalido");
                    i--;
                }
            }

            for(int i = 0; i < nameList.Length; i++)
            {
                if (nameSizeList[i] == 1)
                {
                    lstbxNomes.Items.Add($"o nome {nameList[i]} tem 1 caracter");
                }
                else
                {
                    lstbxNomes.Items.Add($"o nome {nameList[i]} tem {nameSizeList[i]} caracteres");
                }
            }
        }
    }
}
