﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class formExercicio5: Form
    {
        public formExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string respostasPossiveis = "ABCDE";
            char[] gabarito = new char[]{ 'A', 'A', 'B', 'A', 'C', 'E', 'E', 'D', 'D', 'C'};
            //meu ra termina em 11
            int N = 2;
            char[,] respostas = new char[N,10];
            for(int aluno = 0; aluno < N; aluno++)
            {
                for(int questao = 0; questao < 10; questao++)
                {
                    string resposta = Interaction.InputBox($"Digita a nota para a questão {questao + 1} do aluno {aluno + 1}", "Entrada de Notas");
                    //resposta = resposta.ToUpper();
                    if (respostasPossiveis.IndexOf(resposta[0]) != -1)
                    {
                        respostas[aluno, questao] = resposta[0];
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida.");
                        questao--;
                    }
                }
            }
            for (int aluno = 0; aluno < N; aluno++)
            {
                for (int questao = 0; questao < 10; questao++)
                {
                    string msgResposta = (respostas[aluno, questao] == gabarito[questao]) ? "acertou" : "errou";
                    lstbxReultado.Items.Add($"O aluno: {aluno} {msgResposta} a questão: {questao} era {gabarito[questao]} e escolheu {respostas[aluno, questao]}");
                }
            }
        }
    }
}
