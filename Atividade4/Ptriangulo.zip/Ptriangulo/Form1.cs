﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool aIsBetween(double a, double b, double c)
        {
            bool sd = (Math.Abs(b - c) < a) && (a < (a + c));
            return (sd);
        }
        bool compare(double a, double b)
        {
            return (Math.Abs(a - b) < 0.0001);
        }
        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if(double.TryParse(txtLadoA.Text, out double ladoA))
            {
                if (double.TryParse(txtLadoB.Text, out double ladoB))
                {
                    if (double.TryParse(txtLadoC.Text, out double ladoC))
                    {
                        bool isTriangule =
                            aIsBetween(ladoA, ladoB, ladoC) &&
                            aIsBetween(ladoB, ladoA, ladoC) &&
                            aIsBetween(ladoC, ladoA, ladoB);
                        if(isTriangule)
                        {
                            if(compare(ladoA, ladoB))
                            {
                                if(compare(ladoA, ladoC))
                                {
                                    MessageBox.Show("É triangulo equilatero");
                                }
                                else
                                {
                                    MessageBox.Show("É triandgulo isóceles");
                                }
                            }
                            else if(compare(ladoA, ladoC) || compare(ladoB, ladoC))
                            {
                                MessageBox.Show("É triandgulo isóceles");
                            }
                            else 
                            {
                                MessageBox.Show("É triandgulo escaleno");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Não é triangulo");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Lado C invalido");
                    }
                }
                else
                {
                    MessageBox.Show("Lado B invalido");
                }
            } 
            else
            {
                MessageBox.Show("Lado A invalido");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
