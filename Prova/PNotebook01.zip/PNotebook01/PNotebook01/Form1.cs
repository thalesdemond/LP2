﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lstbxRelatorio.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notebooks = new double[3, 3];
            for (int modelo = 0; modelo < 3; modelo++)
            {
                for(int loja = 0;  loja < 3; loja++)
                {
                    string notebook = Interaction.InputBox($"Digite o valor do notebook {modelo+1} da loja {loja+1}.", "Entrada de Valores de notebooks");
                    if (!double.TryParse(notebook, out notebooks[modelo, loja]) || notebooks[modelo, loja] < 0.0)
                    {
                        MessageBox.Show("Valor invalido");
                        loja--;
                    }
                }
            }
            double somaTotal = 0.0;
            for (int modelo = 0; modelo < 3; modelo++)
            {
                string msg = $"Notebook {modelo + 1}: ";
                double somaLoja = 0.0;
                for (int loja = 0; loja < 3; loja++)
                {
                    somaLoja += notebooks[modelo, loja];
                    msg += $"Loja {loja + 1} {notebooks[modelo, loja]:C2}  ";
                }
                msg += $"Média {(somaLoja/3):C2}";
                somaTotal += somaLoja;
                lstbxRelatorio.Items.Add(msg);
            }
            lstbxRelatorio.Items.Add("------------------------");
            lstbxRelatorio.Items.Add($"Média Geral Computadores: {(somaTotal / 9):C2}");
        }
    }
}
