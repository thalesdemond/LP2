﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1: Form
    {
        private double raio = 0;
        private double altura = 0;
        private double volume = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validating(object sender, CancelEventArgs e)
        {
            if(!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Raio invalido!");
            }
            else if(0 >= raio)
            {
                MessageBox.Show("Raio deve ser maior que zero");
            }
        }

        private void txtAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura invalido!");
            }
            else if (0 >= altura)
            {
                MessageBox.Show("Altura deve ser maior que zero");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura invalido!");
                txtAltura.Focus();
            }
            else if (0 >= altura)
            {
                MessageBox.Show("Altura deve ser maior que zero");
                txtAltura.Focus();
            }
            else if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Raio invalido!");
                txtRaio.Focus();
            }
            else if (0 >= raio)
            {
                MessageBox.Show("Raio deve ser maior que zero");
                txtRaio.Focus();
            }
            else
            {
                volume = Math.Pow(raio, 2) * Math.PI * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = "";
            txtVolume.Text = "";
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
