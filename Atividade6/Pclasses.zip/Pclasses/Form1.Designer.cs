﻿namespace Pclasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btMensalista = new System.Windows.Forms.Button();
            this.btHorista = new System.Windows.Forms.Button();
            this.btMessageBox = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btMensalista
            // 
            this.btMensalista.Location = new System.Drawing.Point(85, 103);
            this.btMensalista.Name = "btMensalista";
            this.btMensalista.Size = new System.Drawing.Size(75, 23);
            this.btMensalista.TabIndex = 0;
            this.btMensalista.Text = "Mensalista";
            this.btMensalista.UseVisualStyleBackColor = true;
            this.btMensalista.Click += new System.EventHandler(this.button1_Click);
            // 
            // btHorista
            // 
            this.btHorista.Location = new System.Drawing.Point(237, 103);
            this.btHorista.Name = "btHorista";
            this.btHorista.Size = new System.Drawing.Size(75, 23);
            this.btHorista.TabIndex = 1;
            this.btHorista.Text = "Horista";
            this.btHorista.UseVisualStyleBackColor = true;
            this.btHorista.Click += new System.EventHandler(this.button2_Click);
            // 
            // btMessageBox
            // 
            this.btMessageBox.Location = new System.Drawing.Point(132, 162);
            this.btMessageBox.Name = "btMessageBox";
            this.btMessageBox.Size = new System.Drawing.Size(139, 23);
            this.btMessageBox.TabIndex = 2;
            this.btMessageBox.Text = "Teste MessageBox";
            this.btMessageBox.UseVisualStyleBackColor = true;
            this.btMessageBox.Click += new System.EventHandler(this.btMessageBox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 229);
            this.Controls.Add(this.btMessageBox);
            this.Controls.Add(this.btHorista);
            this.Controls.Add(this.btMensalista);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btMensalista;
        private System.Windows.Forms.Button btHorista;
        private System.Windows.Forms.Button btMessageBox;
    }
}

