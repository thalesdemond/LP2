﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tbTest
{
    public partial class frmFerramenta : Form
    {

        private BindingSource bnFerramenta = new BindingSource(); 
        private bool bInclusao = false;
        private DataSet dsFerramenta = new DataSet();
        private DataSet dsCategoria = new DataSet();
        private DataSet dsFabricante = new DataSet();
        public frmFerramenta()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void frmFerramenta_Load(object sender, EventArgs e)
        {
            try
            {
                Ferramentas RegFerr = new Ferramentas();
                dsFerramenta.Tables.Add(RegFerr.Listar());
                bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                dgvFerramenta.DataSource = bnFerramenta;
                bnvFerramenta.BindingSource = bnFerramenta;

                txtId.DataBindings.Add("TEXT", bnFerramenta, "id");
                txtNome.DataBindings.Add("TEXT", bnFerramenta, "nome");
                cbxDistribuicao.DataBindings.Add("SelectedItem", bnFerramenta, "distribuicao");
                dtDataCadastro.DataBindings.Add("TEXT", bnFerramenta, "dtcadastro");
                txtSite.DataBindings.Add("TEXT", bnFerramenta, "siteoficial");

                // carrega dados da Categoria
                Categoria RegCat = new Categoria();
                dsCategoria.Tables.Add(RegCat.Listar());
                cbxCategoria.DataSource = dsCategoria.Tables["Categoria"];
                //Campo que será mostrado para o usuario
                cbxCategoria.DisplayMember = "DESCRICAO";
                cbxCategoria.ValueMember = "ID";
                //No momento do linkar os componentes com o binding source também
                cbxCategoria.DataBindings.Add("SelectedValue", bnFerramenta, "idCategoria");


                // Carrega dados da Ferramenta

                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());
                cbxFabricante.DataSource = dsFabricante.Tables["FABRICANTE"];
                cbxFabricante.DisplayMember = "NOMEFANTASIA";
                cbxFabricante.ValueMember = "ID";
                cbxFabricante.DataBindings.Add("SelectedValue", bnFerramenta, "idFabricante");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            if(tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }

            bnFerramenta.AddNew();
            txtNome.Enabled = true;
            txtNome.Focus();
            txtSite.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtDataCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;
            cbxCategoria.SelectedIndex = 0;
            cbxDistribuicao.SelectedIndex = 0;
            cbxFabricante.SelectedIndex = 0;
            cbxCategoria.SelectedIndex = 0;
            btnNovoRegistro.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = true;

        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }

           
            txtNome.Enabled = true;
            txtNome.Focus();
            txtSite.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtDataCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;
            //cbxCategoria.SelectedIndex = 0;
            //cbxDistribuicao.SelectedIndex = 0;
            //cbxFabricante.SelectedIndex = 0;
            btnNovoRegistro.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }

            if (MessageBox.Show("Confirma exclusão?", "Yes or No?",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Ferramentas RegFerr = new Ferramentas();
                RegFerr.IdFerramenta = Convert.ToInt32(txtId.Text);

                if (RegFerr.Excluir() > 0)
                {
                    MessageBox.Show("Ferramenta excluida com sucesso!");

                    
                    dsFerramenta.Tables.Clear();
                    dsFerramenta.Tables.Add(RegFerr.Listar());
                    bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Ferramenta!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnFerramenta.CancelEdit();

            txtNome.Enabled = false;
            txtSite.Enabled = false;
            cbxDistribuicao.Enabled = false;
            dtDataCadastro.Enabled = false;
            cbxCategoria.Enabled = false;
            cbxFabricante.Enabled = false;

            btnNovoRegistro.Enabled = true;
            btnAlterar.Enabled = true;  
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || 
                (txtNome.Text.Replace(" ", "").Length <1))
            {
                MessageBox.Show("Nome inválido!");

            }
            else if(cbxDistribuicao.SelectedIndex == -1) 
             {
                MessageBox.Show("Distribuição iválida");
            }
            else if(txtSite.Text == "" ||
                txtSite.Text.Replace(" ","").Length <9)
            {
                MessageBox.Show("Site Oficial inválido");
            }
            else if(Convert.ToDateTime(dtDataCadastro.Value) < DateTime.Today)
            {
                MessageBox.Show("Data inválida!");
            }
            else if(cbxCategoria.SelectedIndex == -1)
            {
                MessageBox.Show("Categoria inválida!");
            }
            else if(cbxFabricante.SelectedIndex == -1)
            {
                MessageBox.Show("Fabricante inválido");
            }
            else
            {
                Ferramentas RegFerr = new Ferramentas();
                RegFerr.Nome = txtNome.Text;
                RegFerr.Distribuicao = Convert.ToChar(cbxDistribuicao.SelectedItem);
                RegFerr.DtCadastro = dtDataCadastro.Value;
                RegFerr.SiteOficial = txtSite.Text;
                RegFerr.IdCategoria = Convert.ToInt32(cbxCategoria.SelectedValue.ToString());
                RegFerr.IdFabricante = Convert.ToInt32(cbxFabricante.SelectedValue.ToString());

                if(bInclusao)
                {
                    if(RegFerr.Salvar()>0)
                    {
                        MessageBox.Show("Ferramenta adicionada com sucesso!");

                        txtNome.Enabled = false;
                        txtSite.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtDataCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnNovoRegistro.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFerr.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar ferramenta!");
                    }
                }
                else // alteração 
                {
                    RegFerr.IdFerramenta = Convert.ToInt32(txtId.Text);

                    if(RegFerr.Alterar() > 0)
                    {
                        MessageBox.Show("Ferramenta alterada com sucesso!");

                        txtNome.Enabled = false;
                        txtSite.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtDataCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnNovoRegistro.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                    }
                }
            }
        }
    }
}
