﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace tbTest
{
    public partial class frmPrincipal: Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //conexao = new SqlConnection("Data Source=APOLO;Initial Catalog=LP2;Persist Security Info=True;User ID=BD2423016; Password = Otavi@éL1ndo");
                conexao = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=LP2;Trusted_Connection=True;\r\n\r\n");
                conexao.Open();
                MessageBox.Show("Conectado!!!");
            }
            catch(SqlException ex)
            {
                MessageBox.Show("Erro no banco de dados = " + ex.Message);
                throw ex;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Outro Erro = " + ex.Message);
               throw ex;
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ferramentasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFerramenta>().Count() > 0)
            {
                Application.OpenForms["frmFerramenta"].BringToFront();

            }
            else
            {
                frmFerramenta frmFerramenta = new frmFerramenta();
                frmFerramenta.MdiParent = this;
                frmFerramenta.WindowState = FormWindowState.Maximized;
                frmFerramenta.Show();

            }
        }

        private void categoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCategoria>().Count() > 0)
            {
                Application.OpenForms["frmCategoria"].BringToFront();

            }
            else
            {
                frmCategoria frmCategoria = new frmCategoria();
                frmCategoria.MdiParent = this;
                frmCategoria.WindowState = FormWindowState.Maximized;
                frmCategoria.Show();
            }
        }

        private void fabricanteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFabricante>().Count() > 0)
            {
                Application.OpenForms["frmFabricante"].BringToFront();
            }
            else
            {
                frmFabricante frmFabricante = new frmFabricante();
                frmFabricante.MdiParent = this;
                frmFabricante.WindowState = FormWindowState.Maximized;
                frmFabricante.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre frmSobre = new frmSobre();
                frmSobre.MdiParent = this;
                frmSobre.WindowState = FormWindowState.Maximized;
                frmSobre.Show();
            }
        }
    }
}
